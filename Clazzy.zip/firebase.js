// Import the functions you need from the SDKs you need
import {initializeApp} from "https://www.gstatic.com/firebasejs/9.10.0/firebase-app.js";
import {
    getAuth,
    createUserWithEmailAndPassword,
    signInWithEmailAndPassword,
    signOut
} from "https://www.gstatic.com/firebasejs/9.10.0/firebase-auth.js";
import {getDatabase, get, set, ref, update} from "https://www.gstatic.com/firebasejs/9.10.0/firebase-database.js";


// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBWLwFfsg92wCiO7uppJStFfKt3CEpjNYs",
    authDomain: "gauthentication-708ec.firebaseapp.com",
    databaseURL: "https://gauthentication-708ec-default-rtdb.firebaseio.com",
    projectId: "gauthentication-708ec",
    storageBucket: "gauthentication-708ec.appspot.com",
    messagingSenderId: "259630487730",
    appId: "1:259630487730:web:dd11edfd99dc8ccbe851ab",
    measurementId: "G-9QEP0M7GPX"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const database = getDatabase(app);

function getUser() {
    const dref = ref(database);
    let cu;
    get ( child( dref, "users/" + user.uid ) ).then( (snapshot) => {
        if( snapshot.exists() ) {
            cu = snapshot.val().designation;
        }
    } );

    if( cu == "Teacher" ){
        let btn = document.getElementById('des').innerHTML;
        btn  = `<button type="button" class="btn btn-outline-primary" id="add-btn"> + Add </button>`;
    }
}

getUser();